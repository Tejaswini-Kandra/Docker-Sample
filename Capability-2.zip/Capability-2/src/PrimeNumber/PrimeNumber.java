package PrimeNumber;
import java.util.Scanner;

public class PrimeNumber {
	public static void main(String args[])
	{
		int n;
		
		Scanner sc =new Scanner(System.in);
		n=sc.nextInt();
		boolean x=isPrime(n);
		System.out.println(x);
		sc.close();
	}
	public static boolean isPrime(int n)
	{
		int c=0;
		
		for(int i=1;i<=n;i++)
		{
			if(n%i==0)
				c++;
		}
		if(c==2)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
