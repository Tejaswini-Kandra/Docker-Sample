package GeneratePwd;
import java.util.Scanner;

public class GeneratePwd {
	public static void main(String args[]) {
		String initial,ch1="";
		int age;
		Scanner sc=new Scanner(System.in);
		
		initial=sc.nextLine();
		age=sc.nextInt();
		
		ch1=ch1+initial.charAt(0);
		
		for(int i=0;i<initial.length();i++)
		{
			
			if(initial.charAt(i)==' ')
				ch1=ch1+initial.charAt(i+1);
		}
		
		System.out.println(ch1+age);
		sc.close();
	}
}
