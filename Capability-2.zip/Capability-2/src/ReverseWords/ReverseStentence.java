package ReverseWords;
import java.util.Scanner;

public class ReverseStentence {
	public static void main(String args[]) {
		
		String str;
		Scanner sc = new Scanner(System.in);
		
		str=sc.nextLine();
		String t="",rev="";
		int len=str.length();
		for(int i=0;i<len;i++)
		{
			
			if((str.charAt(i)>='A' && str.charAt(i)<='Z') ||
					(str.charAt(i)>='a' && str.charAt(i)<='z') || str.charAt(i)==' ')
			{			
				if(str.charAt(i)!=' ')
				{
					t=t+str.charAt(i);
				}
				if(str.charAt(i)==' ' || i==len-1)
				{
					if(t.length()==0)
						rev=rev+" ";
					for(int j=t.length()-1;j>=0;j--)
					{
						rev=rev+t.charAt(j);
						if((j == 0) && (i != len-1))
			                 rev +=" ";
					}
					t="";
				}
				
			}	
			else
			{
				for(int j=t.length()-1;j>=0;j--)
					rev=rev+t.charAt(j);
				t="";
				rev=rev+str.charAt(i);
			}
		}
		System.out.print(rev);
		sc.close();
		
	}
	
}
