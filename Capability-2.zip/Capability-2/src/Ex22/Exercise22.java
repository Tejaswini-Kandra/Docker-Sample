package Ex22;

public class Exercise22 {
	int a[]= new int[8];
	public static void main(String args[])
	{
		
		Exercise22 t=new Exercise22();
			System.out.println(t.a[7]);
	}
}
