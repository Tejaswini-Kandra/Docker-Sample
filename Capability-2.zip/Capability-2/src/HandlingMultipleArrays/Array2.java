package HandlingMultipleArrays;
import java.util.Scanner;

public class Array2 {
	public static void main(String args[]) {
		int x,y;
		Scanner sc = new Scanner(System.in);
		x=sc.nextInt();
		y=sc.nextInt();
		double[] arr1=new double[x] ;
		double[] arr2=new double[y];
		
		for(int i=0;i<x;i++)
			arr1[i]=sc.nextDouble();
		for(int i=0;i<y;i++)
			arr2[i]=sc.nextDouble();
		
		int max=(x>y)?x:y;
		int min=(x<y)?x:y;
		int[] arr=new int[max];
		
		for(int i=0;i<max;i++) {
			if(i<min)
			{
				arr[i]=(int)(arr1[i]+arr2[i]);
				System.out.print(arr[i]+" ");
			}
			else
			{
				if(arr1.length<arr2.length)
				{
					arr[i]=(int)(arr2[i]);
					System.out.print(arr[i]+" ");
				}
				else if(arr1.length>arr2.length)
				{
					arr[i]=(int)(arr1[i]);
					System.out.print(arr[i]+" ");
				}
			}
		}
		
	}

}
