package Ex21;

public class Exercise21 {
	public static void main(String args[])
	{
		int []a= {11,12,13,14,15};
		System.out.println(a.length);
		a=new int[2];
		System.out.println(a.length);
		for(int i=0;i<a.length;i++)
			System.out.println(a[i]);
	}

}
