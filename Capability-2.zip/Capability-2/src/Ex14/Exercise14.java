package Ex14;

public class Exercise14 {
	public static void main(String args[])
	{
		int[][] table=new int[5][10];
		for(int i=0;i<table.length;i++)
			for(int j=0;j<table[i].length;j++)
				table[i][j]=i*10+j;
		for(int i=0;i<table.length;i++)
		{
			for(int j=0;j<table[i].length;j++)
				System.out.print(table[i][j]+"\t");
			System.out.println("");
		}
		
	}

}
