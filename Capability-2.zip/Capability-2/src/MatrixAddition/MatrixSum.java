package MatrixAddition;
import java.util.Scanner;

public class MatrixSum {
	public static void main(String args[])
	{
		int n,m;
		Scanner sc= new Scanner(System.in);
		m=sc.nextInt();
		n=sc.nextInt();
		
		int[][] a1=new int[m][n];
		int[][] a2=new int[m][n];
		int[][] c=new int[m][n];
		for(int i=0;i<m;i++)
			for(int j=0;j<n;j++)
				a1[i][j]=sc.nextInt();
		for(int i=0;i<m;i++)
			for(int j=0;j<n;j++)
				a2[i][j]=sc.nextInt();
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				c[i][j]=a1[i][j]+a2[i][j];
			}
		}
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
				System.out.print(c[i][j]+" ");
			System.out.println("");
		}
		
	}

}
