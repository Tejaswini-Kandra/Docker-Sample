package RowMagic;
import java.util.Scanner;

public class RowMagic {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int m,n;
		m=sc.nextInt();
		n=sc.nextInt();
		int[][] a=new int[m][n];
		for(int i=0;i<m;i++)
			for(int j=0;j<n;j++)
				a[i][j]=sc.nextInt();
		boolean x=isRowMagic(a,m,n);
		if(x==true)
			System.out.println("It is row magic");
		else
			System.out.println("it is not a row magic");
	}
	public static boolean isRowMagic(int[][] a,int m,int n)
	{
		int[] c=new int[m];
		for(int i=0;i<m;i++)
			c[i]=0;
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				c[i]=c[i]+a[i][j];
			}
			//System.out.print(c[i]+" ");
		}
		int first=c[0];
		for(int i=1;i<m;i++)
		{
			if(c[i]!=first)
			{
				return false;
			}
			else
				continue;
		}
		return true;
	}

}
