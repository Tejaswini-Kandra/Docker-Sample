package UniqueElements;
import java.util.Scanner;

public class UniqueElements {
	public static void main(String args[]) {
		int n,m,d=0;
		Scanner sc=new Scanner(System.in);
		m=sc.nextInt();
		n=sc.nextInt();
		int[] arr1=new int[m];
		int[] arr2=new int[n];
		//int[] c=new int[m+n];
		for(int i=0;i<m;i++)
			arr1[i]=sc.nextInt();
		for(int j=0;j<n;j++)
			arr2[j]=sc.nextInt();
				
		uniqueElements(arr1,arr2,m,n,d);
		sc.close();
		
		
	}
	public static void uniqueElements(int[] arr1,int[] arr2,int m,int n,int d)
	{
		
		int len1=m+n;
		int[] c=new int[len1];
		for(int i=0;i<m;i++)
			c[i]=arr1[i];
		for(int i=0;i<n;i++)
			c[m+i]=arr2[i];

		for(int i=0;i<len1;i++)
		{
			for(int j=1;j<len1-i;j++)
			{
				if(c[j-1]>c[j])
				{
					int t=c[j-1];
					c[j-1]=c[j];
					c[j]=t;
				}
			}
		}
		for(int i=0;i<len1;i++)
		{
		d=1;
			while(i<len1-1 && (c[i]==c[i+1]))
			{
				d++;
				i++;
			}
			if(d==1)
			{
			System.out.print(c[i]+" ");
			}
		}
		
	}

}
