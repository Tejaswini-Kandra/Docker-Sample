package StringCompression;
import java.util.Scanner;

public class StringCompression {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String str;
		str=sc.next();
		String str2=convertLowerCase(str);
		//System.out.println(str2);
		int len=str2.length();
		
		for(int i=0;i<len;i++)
		{
			int c=1;
			while(i<len-1 && (str2.charAt(i)==str2.charAt(i+1)))
			{ 
				c++;	
				i++;
			}
			System.out.print(str2.charAt(i));
			System.out.print(c);
		}
			
		
	}
	public static String convertLowerCase(String str)
	{
		String str1="";
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)>='A' && str.charAt(i)<='Z')
			{
				int x=((int)(str.charAt(i))+32);
				str1=str1+(char)x;
			}
			else
				str1=str1+str.charAt(i);
		}
		return str1;
	}

}
