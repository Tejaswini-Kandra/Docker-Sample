package ReverseOrder;
import java.util.Scanner;

public class ReverseDigits {
	public static void main(String args[])
	{
		int n,sum=0,r;
		Scanner sc = new Scanner(System.in);
		n=sc.nextInt();
		
		while(n!=0)
		{
			r=n%10;
			sum=sum*10+r;
			n=n/10;	
		}
		System.out.print(sum);
		sc.close();
	}
}
