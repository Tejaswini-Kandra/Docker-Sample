package StudentMarks;
import java.util.Scanner;

public class StudentMarks {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int[] s=new int[] {1,2,3,4,5,6,7,8,9,10};
		int[] marks=new int[10];
		for(int i=0;i<10;i++)
		{
			marks[i]=sc.nextInt();
			if(marks[i]<0 || marks[i]>25)
			{
				System.out.println("please enter a value with in a range");
				i--;
			}
		}
		int c=0;
		for(int i=0;i<=25;i++)
		{
			for(int j=0;j<10;j++)
			{
				if(i==marks[j])
					c++;
			}
			System.out.println("marks:"+i+"    students:"+c);
			c=0;
		}
		
	}

}
