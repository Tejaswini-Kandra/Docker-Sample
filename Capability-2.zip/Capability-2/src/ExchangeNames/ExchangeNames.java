package ExchangeNames;
import java.util.Scanner;

public class ExchangeNames {
	public static void main(String args[]) {
		String str1,str2,a1="",a2="",b1="",b2="";
		Scanner sc = new Scanner(System.in);
		str1=sc.nextLine();
		str2=sc.nextLine();
		boolean x=false;
		for(int i=0;i<str1.length();i++)
		{
			if(str1.charAt(i)==' ')
				x=true;
			if(x==true)
				b1=b1+str1.charAt(i);
			else
				a1=a1+str1.charAt(i);					
		}
		
		x=false;
		for(int i=0;i<str2.length();i++)
		{
			if(str2.charAt(i)==' ')
				x=true;
			if(x==true)
				b2=b2+str2.charAt(i);
			else
				a2=a2+str2.charAt(i);
		}
		System.out.println(a1+b2);
		System.out.println(a2+b1);
		sc.close();
	}
}
