package Leaders;
import java.util.Scanner;

public class Leader {
	public static void main(String args[])
	{
		int n,j;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		for(int i=0;i<n;i++)
		{
				for (j = i + 1; j < n; j++)  
	            { 
	                if (arr[i] <= arr[j]) 
	                    break; 
	            } 
	            if (j == n) 
	                System.out.print(arr[i] + " ");
				
		}
		sc.close();
	}
}
