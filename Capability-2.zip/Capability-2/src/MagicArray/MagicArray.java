package MagicArray;
import java.util.Scanner;

public class MagicArray {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n;
		n=sc.nextInt();
		int[][] a=new int[n][n];
		for(int i=0;i<n;i++)
			for(int j=0;j<n;j++)
				a[i][j]=sc.nextInt();
		boolean x=isMagic(a,n);
		if(x==true)
			System.out.println("It is a magic square");
		else
			System.out.println("it is not a magic square");
	}
	public static boolean isMagic(int[][] a,int n)
	{
		int[] c=new int[n];
		int[] s=new int[n];
		for(int i=0;i<n;i++)
			c[i]=0;
		int d1=0,d2=0;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)		//for rows
			{
				if(i==j)				
					d1=d1+a[i][j];
				c[i]=c[i]+a[i][j];
			}
			
		}
		for(int k=0;k<n;k++)
			for(int l=0;l<n;l++)
				s[k]=s[k]+a[l][k];
		for(int i=n-1;i>=0;i--)
		{
			for(int j=0;j<n;j++)		// for diagnals
			{
				d2=d2+a[i][j];
			}
		}
		//int q=d1+d2;
		for(int i=0;i<n;i++)
		{
			if(c[i]!=d1 && c[i]!=d2 && s[i]!=d1 && s[i]!=d2)
				return false;
			else
				continue;
		}
		return true;
	}
}
