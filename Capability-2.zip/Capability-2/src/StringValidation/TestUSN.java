package StringValidation;
import java.util.Scanner;

public class TestUSN {
	public static void main(String args[])
	{
		String USN;
		Scanner sc=new Scanner(System.in);
		USN=sc.nextLine();
		
			if(USN.length()==10)
			{
				if(USN.charAt(0)=='1' || USN.charAt(0)=='2')
				{
					
					if(USN.charAt(1)>='A' && USN.charAt(1)<='Z' && USN.charAt(2)>='A' && USN.charAt(2)<='Z')
					{
						if(USN.charAt(3)>='0' && USN.charAt(3)<='9' && USN.charAt(4)>='0' && USN.charAt(4)<='9')
						{
							
							if((USN.charAt(5)=='C' && USN.charAt(6)=='S') || (USN.charAt(5)=='I' && USN.charAt(6)=='S') 
									|| (USN.charAt(5)=='E' && USN.charAt(6)=='C') || (USN.charAt(5)=='M' && USN.charAt(6)=='E'))
							{
								
									if((USN.charAt(7)>='0' && USN.charAt(7)<='9') && (USN.charAt(8)>='0' && USN.charAt(8)<='9') 
											&& (USN.charAt(9)>='0' && USN.charAt(9)<='9'))
									{
										
										System.out.println("Success");
									}
									else
										System.out.println("Failure");
							}
							else
								System.out.println("Failure");
							
						}
					}
					else
						System.out.println("Failure");
				}
				else
					System.out.println("Failure");
			}
			else
				System.out.println("Failure");
			sc.close();
		
	}

}
