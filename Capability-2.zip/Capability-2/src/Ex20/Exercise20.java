package Ex20;

public class Exercise20 {
	public static void main(String args[])
	{
		int[] a=new int[2];
		System.out.println(a[0]);
		System.out.println(a[1]);
	}

}
