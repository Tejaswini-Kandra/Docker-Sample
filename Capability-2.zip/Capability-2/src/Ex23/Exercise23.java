package Ex23;

public class Exercise23 {
	public static void main(String args[])
	{
		int[] a=new int[5];
		a=new int[10];
		//a.length=10;   array.length cannot be assigned
		System.out.println(a.length);
	}

}
