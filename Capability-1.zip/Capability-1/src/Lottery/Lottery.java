package Lottery;
import java.util.Scanner;

public class Lottery {
	public static void main(String args[]) {
		int a,b,c;
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		b=sc.nextInt();
		c=sc.nextInt();
		fun(a,b,c);
	}
	public static void fun(int a,int b,int c) {
		if(a!=b && b!=c && a!=c) {
			System.out.println("resulit is 0");
		}
		else if(a==b && b==c && a==c) {
			System.out.println("resulit is 20");
		}
		else {
			System.out.println("resulit is 10");
		}
	}
}
