package Program16;

public class program16 {
	public static void main(String args[]) {
		String str=NULL;
		System.out.println(str);
	}

}
