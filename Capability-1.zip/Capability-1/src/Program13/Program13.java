package Program13;

public class Program13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		System.out.println(num);

	}

}
