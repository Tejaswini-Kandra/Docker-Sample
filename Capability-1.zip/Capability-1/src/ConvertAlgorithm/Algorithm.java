package ConvertAlgorithm;
import java.util.Scanner;

public class Algorithm {
	public static void main(String args[]) 
	{
		int a,b;
		Scanner sc = new Scanner(System.in);
		a=sc.nextInt();
		b=sc.nextInt();
		if(a>b || (a<=0 || b<=0))
			System.out.println("Invalid");
		
		else 
		{
			for(int i=0;i<10;i++) 
			{
				a=a+b;
				b=b+10;
			}
			System.out.println("a value is:"+a);
			System.out.println("b value is:"+b);
		}
		
	}

}
