package Program12;

public class Program12 {
	public static void main(String args[])
	{
		long ln=200L;
		float fn=123.5f;
		double dn=12.5;
		
		dn=fn;  /* here  Type-Casting is NOT required to convert from float to double */
		
		//ln=(long)fn;
		ln=fn;  /* here explicit Type-Casting is required to convert from float to long */
		
		System.out.println("dn");
		System.out.println(ln);
	}
}
