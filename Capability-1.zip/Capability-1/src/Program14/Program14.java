package Program14;

public class Program14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1=100;
		int n2=100;
		
		if((n1<=50) && (++n1>=100))
			System.out.println("TRUE");
		if((n2>=50) && (++n2<=100))
			System.out.println("TRUE");
		System.out.println(n1);
		System.out.println(n2);
	}

}
