package Fibonacci;
import java.util.Scanner;

public class Fib {
	public static void main(String args[])
	{
		int n;
		Scanner sc = new Scanner(System.in);
		n=sc.nextInt();
		evenFibSum(n);
	}
	public static void evenFibSum(int n) {
		int a=0,b=1,c,sum=0,t;
		c=a+b;
		
		for(;c<=n;) {
			System.out.println("fibonacci series is:"+c);
			if(c%2==0)
				sum=sum+c;
			t=c+b;
			b=c;
			c=t;
			
		}
		System.out.println("sum is : "+sum);
	}
}
