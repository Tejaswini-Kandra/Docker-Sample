package LcmANDGcd;
import java.util.Scanner;

public class LcmGcd {
	public static void main(String args[]) {
		int a,b;
		Scanner sc = new Scanner(System.in);
		a=sc.nextInt();
		b=sc.nextInt();
		LCM(a,b);
		gcd(a,b);
		sc.close();
	}
	public static void LCM(int a, int b)
	{
		int x;
		x=(a>b)?a:b;
		while(true)
		{
		if(x%a==0 && x%b==0) {
			System.out.println(x);
			return;
			
		}
		++x;
		}
	}
	public static void gcd(int a,int b) {
		int r=0;
		r=b;
		while(a%b!=0)
		{
			r=a%b;
			a=b;
			b=r;
		}
		
		System.out.println(r);
	}
}

