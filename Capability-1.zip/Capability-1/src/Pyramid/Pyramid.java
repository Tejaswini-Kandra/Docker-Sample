package Pyramid;
import java.util.Scanner;

public class Pyramid {
	public static void main(String args[]) {
		int i,j,n,c;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		
		for(i=1;i<=n;i++)
		{
			for(c=1;c<=n-i;c++)
			{
				System.out.print(" ");
			}
			for(j=1;j<=i;j++)
			{
				System.out.print(""+i);
				System.out.print(" ");
			}
			System.out.println("");
			c--;
		}
	}

}
