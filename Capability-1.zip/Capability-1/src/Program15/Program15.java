package Program15;

public class Program15 {

	public static void main(String[] args) {
		int ok=0;
		if(ok)
			System.out.println("True");
		else
			System.out.println("False");

	}

}
