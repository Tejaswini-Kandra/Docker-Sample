package HailstoneSequence;
import java.util.Scanner;
public class Hailstone {
	public static void main(String args[]) {
		
		int n;
		Scanner sc = new Scanner(System.in);
		n=sc.nextInt();
		while(n!=1)
		{
			if(n%2==0)
			{
				System.out.println(n+"is even so i take half: "+n/2);
				n=n/2;
			}
			else
			{
				System.out.println(n+"is odd so i make 3n+1: "+3*n+1);
				n=3*n+1;
			}
		}
		sc.close();
	}

}
