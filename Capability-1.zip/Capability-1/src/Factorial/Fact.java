package Factorial;
import java.util.Scanner;

public class Fact {
	public static void main(String args[]) {
		
		int i,n,fact=1;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		/*for(i=n;i>=1;i--)
		{
			fact=fact*i;
		}*/
		i=n;
		
		while(i>=1) {
			fact=fact*i;
			i--;
		}
		System.out.println(""+fact);
	}
}
