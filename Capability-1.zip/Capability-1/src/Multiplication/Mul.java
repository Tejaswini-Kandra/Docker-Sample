package Multiplication;
import java.util.Scanner;

public class Mul {
	public static void main(String args[])
	{
		int n,i;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		/*for(i=1;i<=12;i++)
		{
			System.out.println(n +"*"+i+"="+n*i);
		}*/
		i=1;
		while(i<=12) {
			System.out.println(n +"*"+i+"="+n*i);
			i++;
		}
	}

}
