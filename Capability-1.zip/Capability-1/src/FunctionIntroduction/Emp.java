package FunctionIntroduction;
import java.util.Scanner;

public class Emp {
	public static void main(String args[])
	{
		int id,code;
		String band;
		Scanner sc = new Scanner(System.in);
		id = sc.nextInt();
		code = sc.nextInt();
		band = sc.next();
		fun1(id,code,band);
		
		
	}
	public static void fun1(int id,int code,String band) {
		
		if(code>=110 && code<=125) {
			
			if(band.equals("C1") || band.equals("C2") || band.equals("C3") || band.equals("C4")) {
				System.out.println("Employee id:"+id);
				System.out.println("Department code:"+code);
				System.out.println("Employee job band is : "+band);
			}
			else
				System.out.println("error");
		}
		else
			System.out.println("error");
		
	}
	
}
